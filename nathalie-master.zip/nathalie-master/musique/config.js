exports.TOKEN = process.env.token;

exports.PREFIX = '!';

exports.GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
