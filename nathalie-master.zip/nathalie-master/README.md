# nathalie
Code open Source.
If you want to use the code, you can.
If you want more information about the code, go to this server discord : https://discord.gg/g2WSzzf
